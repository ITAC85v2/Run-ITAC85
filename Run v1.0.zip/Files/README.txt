Run, v.1.0
--------------------------------------------
 Run is a batch script that can run applications for you.
--------------------------------------------
Version 1.0
--------------------------------------------
Please do not modify the files in these folders. Modifying these files may cause damage to Run, which may require reinstallation to fix.
If you want to run a program, please go back to the "run" folder.
--------------------------------------------