Run, v.1.0
-----------------------
ABOUT RUN

   Version Information: Version 1.0, created on 5/14/2020.
   Version finished on: 5/15/2020
--------------------------------------------------
Run, v.1.0
   This is an application that can run applications for you. This is not the "Run 1, 2, or 3" game.

  When would I need Run?
-Having problems running programs via the start menu? Run will help.
-Task Manager won't run? Run can do that.
-Window Key + R won't show the "run program" screen? Run will run it for you!
-Lazy? Run.
-Confused on where to find some of your apps? Run will locate them and run it.
-Can't run an app that should be able to work? Run loads it.
----------------------------------------------------
   How to uninstall Run
-Go to the "Run v1.0" folder
-Open the "Uninstall" folder
-Open "uninstall.bat".
-Wait
-Run has now successfully been uninstalled from your computer.
--------------------------------------------------
   How to report a bug
-Go to the "Run v1.0" folder
-Open the "Bug Report" folder
-Open "report.bat" or "report2.bat".
-Type the problem(s) you are experiencing, and then save the text document. (saves to [destination]\Run v1.0\Bug Report\Report\)
-Show me the text document, and I will work on this application!
-------------------------------------------------
   How to request for new features
-Go to the "Run v1.0" folder
-Open the "New Feature Request" folder
-Open "request.bat"
-Type the feature(s) you would like to be added, then save the text document. (saves to [destintion]\Run v1.0\New Feature Request\Files\)
---------------------------------------------------------------------------------------------------------------------------
   Please note that at the moment, Run can only open basic programs as listed in Run.bat. We will work on Run!
---------------------------------------------------------------------------------------------------------------------------
2020, Run v1.0.